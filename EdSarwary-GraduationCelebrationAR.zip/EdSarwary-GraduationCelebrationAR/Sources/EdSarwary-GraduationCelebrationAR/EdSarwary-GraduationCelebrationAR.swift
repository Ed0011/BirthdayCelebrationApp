import Foundation

/// Bundle for the EdSarwary-GraduationCelebrationAR project
public let edSarwary_GraduationCelebrationARBundle = Bundle.module